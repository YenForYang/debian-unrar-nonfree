#ifndef _RAR_SMALLFN_
#define _RAR_SMALLFN_

int ToPercent(int64 N1,int64 N2);
int ToPercentUnlim(int64 N1,int64 N2);
void RARInitData();

#endif
